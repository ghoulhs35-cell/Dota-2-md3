# DotaPulse MD3 (`com.dotapulse.md3`)

A **100% pure Java**, offline-first **Material Design 3 (Material You)** Android application for live Dota 2 hero meta intelligence, dead-hero detection, and personal Steam account meta auditing.

## Architecture Highlights

- **Pure Java + Material Design 3**: Built with `com.google.android.material:material:1.12.0`, full dark tonal surface elevation (`surfaceContainerLowest` through `surfaceContainerHighest`), semantic tonal banners (`secondaryContainer` for S-Tier Meta Kings, `errorContainer` for D-Tier Dead Heroes, `primaryContainer` for Steam Audit CTAs), `BottomNavigationView` with pill indicator and `BadgeDrawable`, and Android 12+ `DynamicColors`.
- **Vertical-Snap Telemetry Viewport**: Full-bleed vertical `ViewPager2` feed featuring floating MD3 `FilledTonal` icon buttons, interactive `AssistChip` tags, centered translucent MD3 watermark pills, and dynamic top status banners.
- **Resilient OpenDota + Room Offline Cache**: Fetches live telemetry from `https://api.opendota.com/api/heroStats` with a 30-minute Room SQLite cache and a bundled 30-hero Patch 7.42 dataset (`app/src/main/assets/seed_hero_stats.json`) for instant cold launch even in airplane mode.
- **Zero-Backend Steam OpenID 2.0 & Account Audit**: Authenticates via `https://steamcommunity.com/openid/login` inside a host-restricted `WebView` (or accepts any public 64-bit SteamID / 32-bit Friend ID / Steam profile URL), converts 64-bit SteamIDs to 32-bit Dota 2 Account IDs, and audits recent matches and hero pools against global meta tiers.

## Project Structure

```text
dotapulse-md3/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/
        │   └── seed_hero_stats.json
        ├── java/com/dotapulse/md3/
        │   ├── DotaPulseApplication.java
        │   ├── auth/
        │   │   ├── SessionManager.java
        │   │   ├── SteamIdConverter.java
        │   │   └── SteamOpenIdAuthActivity.java
        │   ├── db/
        │   │   ├── AppDatabase.java
        │   │   ├── HeroMetaDao.java
        │   │   └── HeroRepository.java
        │   ├── engine/
        │   │   ├── MetaClassifierEngine.java
        │   │   └── SteamAuditEngine.java
        │   ├── model/
        │   │   ├── HeroMetaEntity.java
        │   │   ├── HeroStatsDto.java
        │   │   ├── PlayerHeroPerformance.java
        │   │   ├── PlayerRecentMatch.java
        │   │   ├── PlayerWinLossDto.java
        │   │   ├── SteamAuditReport.java
        │   │   └── SteamPlayerProfile.java
        │   ├── network/
        │   │   ├── OpenDotaApiService.java
        │   │   └── RetrofitClient.java
        │   └── ui/
        │       ├── MainActivity.java
        │       ├── audit/SteamAuditFragment.java
        │       ├── compare/HeroCompareBottomSheet.java
        │       ├── deadlist/DeadHeroesFragment.java
        │       ├── feed/HeroDetailBottomSheet.java
        │       ├── feed/HeroFeedAdapter.java
        │       └── md3/Md3StatusBannerController.java
        └── res/
            ├── drawable/
            ├── layout/
            ├── menu/
            └── values/
```

## Build & Run

1. Open `dotapulse-md3/` in **Android Studio** (Giraffe / Koala / Ladybug or newer) with JDK 17.
2. Sync Gradle and run on an Android 8.0+ (`minSdk 26`) device or emulator, or build a debug APK via CLI:
   ```bash
   ./gradlew assembleDebug
   ```
3. Output APK location: `app/build/outputs/apk/debug/app-debug.apk`.
