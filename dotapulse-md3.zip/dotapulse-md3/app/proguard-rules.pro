# Gson model classes
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.dotapulse.md3.model.** { *; }

# Retrofit
-keepattributes Exceptions,InnerClasses,Signature,Deprecated,SourceFile,LineNumberTable,*Annotation*,EnclosingMethod
-keep interface com.dotapulse.md3.network.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**
