package com.dotapulse.md3.model;

import com.google.gson.annotations.SerializedName;

public class PlayerWinLossDto {
    @SerializedName("win")
    public int win;

    @SerializedName("lose")
    public int lose;
}
