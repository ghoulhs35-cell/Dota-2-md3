package com.dotapulse.md3.model;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "hero_meta")
public class HeroMetaEntity {
    @PrimaryKey
    public int heroId;

    @NonNull
    public String localizedName = "";

    @NonNull
    public String shortName = "";

    @NonNull
    public String primaryAttr = "ALL";

    @NonNull
    public String attackType = "Melee";

    @NonNull
    public String rolesCsv = "Flex";

    public double overallWinRate;
    public double highMmrWinRate;
    public double heraldCrusaderWr;
    public double archonLegendWr;
    public double ancientDivineWr;
    public double immortalWr;

    public double pickRate;
    public double proContestRate;
    public double winRateDelta;
    public double metaScore;

    @NonNull
    public String tierLabel = "B";

    public boolean isDeadHero;

    @NonNull
    public String statusBannerTitle = "";

    @NonNull
    public String verdictSummary = "";

    public long totalPubPicks;
    public int proMatchesSample;
    public boolean isWatchlisted;
    public boolean isLiked;
    public long lastUpdatedEpoch;

    public String getHeroPortraitUrl() {
        return "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/" + shortName + ".png";
    }

    public String getHeroIconUrl() {
        return "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/icons/" + shortName + ".png";
    }

    public String getPrimaryRole() {
        if (rolesCsv == null || rolesCsv.isEmpty()) {
            return "Flex";
        }
        int sep = rolesCsv.indexOf(" • ");
        return sep > 0 ? rolesCsv.substring(0, sep) : rolesCsv;
    }
}
