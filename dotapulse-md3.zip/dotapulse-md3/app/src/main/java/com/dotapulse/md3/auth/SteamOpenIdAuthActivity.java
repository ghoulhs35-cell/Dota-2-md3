package com.dotapulse.md3.auth;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.dotapulse.md3.R;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class SteamOpenIdAuthActivity extends AppCompatActivity {

    public static final String EXTRA_ACCOUNT_ID_32 = "extra_account_id_32";
    private static final String CALLBACK_HOST = "dotapulse.local";
    private static final String RETURN_TO_URL = "https://dotapulse.local/auth/callback";
    private static final String REALM_URL = "https://dotapulse.local";

    private WebView webView;
    private LinearProgressIndicator progressIndicator;
    private SessionManager sessionManager;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steam_auth);

        sessionManager = new SessionManager(this);

        MaterialToolbar toolbar = findViewById(R.id.toolbarSteamAuth);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        progressIndicator = findViewById(R.id.progressSteamWeb);
        webView = findViewById(R.id.webViewSteamOpenId);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressIndicator.setProgressCompat(newProgress, true);
                progressIndicator.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return true;

                String host = uri.getHost();
                if (CALLBACK_HOST.equalsIgnoreCase(host)) {
                    handleOpenIdCallback(uri);
                    return true;
                }

                // Restrict navigation strictly to official Steam hosts
                if (host != null && (host.endsWith("steamcommunity.com") || host.endsWith("steampowered.com"))) {
                    return false;
                }
                return true;
            }
        });

        final TextInputLayout tilManual = findViewById(R.id.tilManualSteamInput);
        final TextInputEditText etManual = findViewById(R.id.etManualSteamInput);
        MaterialButton btnManual = findViewById(R.id.btnManualSteamAudit);

        btnManual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String raw = etManual.getText() != null ? etManual.getText().toString() : "";
                long accountId32 = SteamIdConverter.parseToAccountId32(raw);
                if (accountId32 <= 0L) {
                    tilManual.setError("Enter a valid Friend ID, 64-bit SteamID, or profile URL");
                    return;
                }
                tilManual.setError(null);
                completeWithAccountId(accountId32, String.valueOf(SteamIdConverter.toSteamId64(accountId32)));
            }
        });

        webView.loadUrl(buildSteamOpenIdUri().toString());
    }

    private Uri buildSteamOpenIdUri() {
        return Uri.parse("https://steamcommunity.com/openid/login")
                .buildUpon()
                .appendQueryParameter("openid.ns", "http://specs.openid.net/auth/2.0")
                .appendQueryParameter("openid.mode", "checkid_setup")
                .appendQueryParameter("openid.return_to", RETURN_TO_URL)
                .appendQueryParameter("openid.realm", REALM_URL)
                .appendQueryParameter("openid.identity", "http://specs.openid.net/auth/2.0/identifier_select")
                .appendQueryParameter("openid.claimed_id", "http://specs.openid.net/auth/2.0/identifier_select")
                .build();
    }

    private void handleOpenIdCallback(Uri callbackUri) {
        String claimedId = callbackUri.getQueryParameter("openid.claimed_id");
        long accountId32 = SteamIdConverter.parseToAccountId32(claimedId);
        if (accountId32 > 0L) {
            String steamId64 = String.valueOf(SteamIdConverter.toSteamId64(accountId32));
            completeWithAccountId(accountId32, steamId64);
        } else {
            Toast.makeText(this, "Steam OpenID cancelled or invalid response.", Toast.LENGTH_SHORT).show();
        }
    }

    private void completeWithAccountId(long accountId32, String steamId64) {
        sessionManager.saveSession(accountId32, steamId64, "Player #" + accountId32, "");
        Intent data = new Intent();
        data.putExtra(EXTRA_ACCOUNT_ID_32, accountId32);
        setResult(RESULT_OK, data);
        finish();
    }
}
