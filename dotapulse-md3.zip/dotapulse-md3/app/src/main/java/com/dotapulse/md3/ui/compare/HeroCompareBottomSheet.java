package com.dotapulse.md3.ui.compare;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.dotapulse.md3.R;
import com.dotapulse.md3.auth.SteamIdConverter;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HeroCompareBottomSheet extends BottomSheetDialogFragment {

    public interface QuickAuditCallback {
        void onQuickAuditRequested(long accountId32);
    }

    private List<HeroMetaEntity> heroes = new ArrayList<>();
    private QuickAuditCallback quickAuditCallback;
    private HeroMetaEntity selectedA;
    private HeroMetaEntity selectedB;

    private TextView tvCompareMetaScore;
    private LinearProgressIndicator progressCompareScore;
    private TextView tvCompareWinRates;
    private TextView tvCompareVerdict;

    public static HeroCompareBottomSheet newInstance(List<HeroMetaEntity> heroes, QuickAuditCallback callback) {
        HeroCompareBottomSheet sheet = new HeroCompareBottomSheet();
        if (heroes != null) {
            sheet.heroes = new ArrayList<>(heroes);
        }
        sheet.quickAuditCallback = callback;
        return sheet;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_compare, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (heroes.size() < 2) {
            dismiss();
            return;
        }

        selectedA = heroes.get(0);
        selectedB = heroes.get(heroes.size() - 1);

        AutoCompleteTextView actvA = view.findViewById(R.id.actvHeroA);
        AutoCompleteTextView actvB = view.findViewById(R.id.actvHeroB);
        tvCompareMetaScore = view.findViewById(R.id.tvCompareMetaScore);
        progressCompareScore = view.findViewById(R.id.progressCompareScore);
        tvCompareWinRates = view.findViewById(R.id.tvCompareWinRates);
        tvCompareVerdict = view.findViewById(R.id.tvCompareVerdict);

        List<String> names = new ArrayList<>(heroes.size());
        for (HeroMetaEntity h : heroes) {
            names.add(h.localizedName + " (" + h.tierLabel + ")");
        }

        ArrayAdapter<String> adapterA = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, names);
        ArrayAdapter<String> adapterB = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, names);

        actvA.setAdapter(adapterA);
        actvB.setAdapter(adapterB);
        actvA.setText(names.get(0), false);
        actvB.setText(names.get(names.size() - 1), false);

        actvA.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                selectedA = heroes.get(position);
                updateComparison();
            }
        });

        actvB.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                selectedB = heroes.get(position);
                updateComparison();
            }
        });

        final TextInputEditText etQuickId = view.findViewById(R.id.etSheetQuickSteamId);
        MaterialButton btnQuickAudit = view.findViewById(R.id.btnSheetQuickAudit);
        btnQuickAudit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String raw = etQuickId.getText() != null ? etQuickId.getText().toString() : "";
                long accountId32 = SteamIdConverter.parseToAccountId32(raw);
                if (accountId32 <= 0L) {
                    Toast.makeText(requireContext(), "Enter a valid Friend ID or 64-bit SteamID", Toast.LENGTH_SHORT).show();
                    return;
                }
                dismiss();
                if (quickAuditCallback != null) {
                    quickAuditCallback.onQuickAuditRequested(accountId32);
                }
            }
        });

        updateComparison();
    }

    private void updateComparison() {
        if (selectedA == null || selectedB == null) return;
        tvCompareMetaScore.setText(String.format(Locale.US,
                "Meta Score: %.1f vs %.1f", selectedA.metaScore, selectedB.metaScore));

        double total = Math.max(1.0, selectedA.metaScore + selectedB.metaScore);
        int ratio = (int) Math.round((selectedA.metaScore * 100.0) / total);
        progressCompareScore.setProgress(ratio);

        tvCompareWinRates.setText(String.format(Locale.US,
                "All-Bracket WR: %.1f%% vs %.1f%%
High-MMR WR: %.1f%% vs %.1f%%
Pick Rate: %.1f%% vs %.1f%%",
                selectedA.overallWinRate, selectedB.overallWinRate,
                selectedA.highMmrWinRate, selectedB.highMmrWinRate,
                selectedA.pickRate, selectedB.pickRate));

        double diff = selectedA.metaScore - selectedB.metaScore;
        if (diff >= 0) {
            tvCompareVerdict.setText(String.format(Locale.US,
                    "Advantage: %s (+%.1f Meta Score)", selectedA.localizedName, diff));
        } else {
            tvCompareVerdict.setText(String.format(Locale.US,
                    "Advantage: %s (+%.1f Meta Score)", selectedB.localizedName, -diff));
        }
    }
}
