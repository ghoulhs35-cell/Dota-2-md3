package com.dotapulse.md3.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.dotapulse.md3.model.HeroMetaEntity;

import java.util.List;

@Dao
public interface HeroMetaDao {
    @Query("SELECT * FROM hero_meta ORDER BY metaScore DESC")
    List<HeroMetaEntity> getAllHeroesByMetaScore();

    @Query("SELECT * FROM hero_meta WHERE isDeadHero = 1 ORDER BY metaScore ASC")
    List<HeroMetaEntity> getDeadHeroes();

    @Query("SELECT * FROM hero_meta WHERE isWatchlisted = 1 ORDER BY metaScore DESC")
    List<HeroMetaEntity> getWatchlistedHeroes();

    @Query("SELECT * FROM hero_meta WHERE heroId = :heroId LIMIT 1")
    HeroMetaEntity getHeroById(int heroId);

    @Query("SELECT COUNT(*) FROM hero_meta")
    int countHeroes();

    @Query("SELECT MAX(lastUpdatedEpoch) FROM hero_meta")
    Long getLatestTimestamp();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<HeroMetaEntity> heroes);

    @Query("UPDATE hero_meta SET isWatchlisted = :watchlisted WHERE heroId = :heroId")
    void updateWatchlist(int heroId, boolean watchlisted);

    @Query("UPDATE hero_meta SET isLiked = :liked WHERE heroId = :heroId")
    void updateLiked(int heroId, boolean liked);
}
