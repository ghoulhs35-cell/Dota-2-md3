package com.dotapulse.md3.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class HeroStatsDto {
    @SerializedName("id")
    public int id;

    @SerializedName("name")
    public String name;

    @SerializedName("localized_name")
    public String localizedName;

    @SerializedName("primary_attr")
    public String primaryAttr;

    @SerializedName("attack_type")
    public String attackType;

    @SerializedName("roles")
    public List<String> roles;

    @SerializedName("img")
    public String img;

    @SerializedName("icon")
    public String icon;

    @SerializedName("pro_pick")
    public int proPick;

    @SerializedName("pro_ban")
    public int proBan;

    @SerializedName("pro_win")
    public int proWin;

    @SerializedName("1_pick")
    public int bracket1Pick;
    @SerializedName("1_win")
    public int bracket1Win;

    @SerializedName("2_pick")
    public int bracket2Pick;
    @SerializedName("2_win")
    public int bracket2Win;

    @SerializedName("3_pick")
    public int bracket3Pick;
    @SerializedName("3_win")
    public int bracket3Win;

    @SerializedName("4_pick")
    public int bracket4Pick;
    @SerializedName("4_win")
    public int bracket4Win;

    @SerializedName("5_pick")
    public int bracket5Pick;
    @SerializedName("5_win")
    public int bracket5Win;

    @SerializedName("6_pick")
    public int bracket6Pick;
    @SerializedName("6_win")
    public int bracket6Win;

    @SerializedName("7_pick")
    public int bracket7Pick;
    @SerializedName("7_win")
    public int bracket7Win;

    @SerializedName("8_pick")
    public int bracket8Pick;
    @SerializedName("8_win")
    public int bracket8Win;

    @SerializedName("pub_pick")
    public long pubPick;

    @SerializedName("pub_win")
    public long pubWin;

    public long getTotalPubPicks() {
        long sum = (long) bracket1Pick + bracket2Pick + bracket3Pick + bracket4Pick
                + bracket5Pick + bracket6Pick + bracket7Pick + bracket8Pick;
        return sum > 0 ? sum : pubPick;
    }

    public long getTotalPubWins() {
        long sum = (long) bracket1Win + bracket2Win + bracket3Win + bracket4Win
                + bracket5Win + bracket6Win + bracket7Win + bracket8Win;
        return sum > 0 ? sum : pubWin;
    }
}
