package com.dotapulse.md3.engine;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.dotapulse.md3.auth.SessionManager;
import com.dotapulse.md3.auth.SteamIdConverter;
import com.dotapulse.md3.db.HeroRepository;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.dotapulse.md3.model.PlayerHeroPerformance;
import com.dotapulse.md3.model.PlayerRecentMatch;
import com.dotapulse.md3.model.PlayerWinLossDto;
import com.dotapulse.md3.model.SteamAuditReport;
import com.dotapulse.md3.model.SteamPlayerProfile;
import com.dotapulse.md3.network.OpenDotaApiService;
import com.dotapulse.md3.network.RetrofitClient;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Response;

public class SteamAuditEngine {

    private final Context appContext;
    private final HeroRepository heroRepository;
    private final SessionManager sessionManager;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface AuditCallback {
        void onAuditComplete(SteamAuditReport report);
        void onAuditError(String message);
    }

    public SteamAuditEngine(Context context) {
        this.appContext = context.getApplicationContext();
        this.heroRepository = new HeroRepository(appContext);
        this.sessionManager = new SessionManager(appContext);
    }

    public void runAudit(final long accountId32, final AuditCallback callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Map<Integer, HeroMetaEntity> heroMap = heroRepository.getHeroMapBlocking();
                    OpenDotaApiService api = RetrofitClient.getApiService();

                    Response<SteamPlayerProfile> profileResp = api.getPlayerProfile(accountId32).execute();
                    Response<PlayerWinLossDto> wlResp = api.getPlayerWinLoss(accountId32).execute();
                    Response<List<PlayerHeroPerformance>> heroesResp = api.getPlayerHeroes(accountId32).execute();
                    Response<List<PlayerRecentMatch>> recentResp = api.getPlayerRecentMatches(accountId32).execute();

                    final SteamAuditReport report = new SteamAuditReport();
                    report.accountId32 = accountId32;
                    report.steamId64 = String.valueOf(SteamIdConverter.toSteamId64(accountId32));
                    report.personaName = "Dota 2 Player #" + accountId32;
                    report.avatarUrl = "";

                    if (profileResp.isSuccessful() && profileResp.body() != null && profileResp.body().profile != null) {
                        SteamPlayerProfile.ProfileDetail p = profileResp.body().profile;
                        if (p.personaname != null && !p.personaname.isEmpty()) {
                            report.personaName = p.personaname;
                        }
                        if (p.avatarfull != null) {
                            report.avatarUrl = p.avatarfull;
                        }
                        if (p.steamid != null && !p.steamid.isEmpty()) {
                            report.steamId64 = p.steamid;
                        }
                        sessionManager.saveSession(accountId32, report.steamId64, report.personaName, report.avatarUrl);
                    }

                    if (wlResp.isSuccessful() && wlResp.body() != null) {
                        report.totalWins = wlResp.body().win;
                        report.totalLosses = wlResp.body().lose;
                        int total = report.totalWins + report.totalLosses;
                        report.overallWinRate = total > 0 ? (report.totalWins * 100.0) / total : 0.0;
                    }

                    List<PlayerRecentMatch> recentMatches = (recentResp.isSuccessful() && recentResp.body() != null)
                            ? recentResp.body() : Collections.<PlayerRecentMatch>emptyList();
                    List<PlayerHeroPerformance> heroPerfs = (heroesResp.isSuccessful() && heroesResp.body() != null)
                            ? heroesResp.body() : Collections.<PlayerHeroPerformance>emptyList();

                    if (recentMatches.isEmpty() && (report.totalWins + report.totalLosses) == 0) {
                        report.isPrivateProfile = true;
                        postReport(report, callback);
                        return;
                    }

                    // Analyze recent 20 matches
                    int recentWins = 0;
                    int deadMatches = 0;
                    double metaScoreSum = 0.0;
                    long totalGpm = 0L;
                    long totalXpm = 0L;
                    double totalKda = 0.0;

                    for (PlayerRecentMatch m : recentMatches) {
                        if (m.isWin()) recentWins++;
                        totalGpm += m.goldPerMin;
                        totalXpm += m.xpPerMin;
                        totalKda += (m.kills + m.assists) / (double) Math.max(1, m.deaths);

                        HeroMetaEntity meta = heroMap.get(m.heroId);
                        if (meta != null) {
                            metaScoreSum += meta.metaScore;
                            if (meta.isDeadHero || "D".equals(meta.tierLabel) || "C".equals(meta.tierLabel)) {
                                deadMatches++;
                            }
                        } else {
                            metaScoreSum += 50.0;
                        }
                    }

                    int sampleSize = Math.max(1, recentMatches.size());
                    report.recent20WinRate = recentMatches.isEmpty()
                            ? report.overallWinRate : (recentWins * 100.0) / sampleSize;
                    report.metaAlignmentScore = recentMatches.isEmpty()
                            ? 55 : (int) Math.round(metaScoreSum / sampleSize);
                    report.deadHeroTrapRate = recentMatches.isEmpty()
                            ? 0.0 : (deadMatches * 100.0) / sampleSize;
                    report.avgGpm = (int) (totalGpm / sampleSize);
                    report.avgXpm = (int) (totalXpm / sampleSize);
                    report.avgKda = totalKda / sampleSize;

                    // Sort player heroes by games played descending
                    Collections.sort(heroPerfs, new Comparator<PlayerHeroPerformance>() {
                        @Override
                        public int compare(PlayerHeroPerformance a, PlayerHeroPerformance b) {
                            return Integer.compare(b.games, a.games);
                        }
                    });

                    int limit = Math.min(12, heroPerfs.size());
                    for (int i = 0; i < limit; i++) {
                        PlayerHeroPerformance perf = heroPerfs.get(i);
                        if (perf.games <= 0) continue;

                        HeroMetaEntity meta = heroMap.get(perf.heroId);
                        if (meta == null) continue;

                        SteamAuditReport.HeroAuditItem item = new SteamAuditReport.HeroAuditItem();
                        item.heroId = perf.heroId;
                        item.heroName = meta.localizedName;
                        item.heroPortraitUrl = meta.getHeroPortraitUrl();
                        item.gamesPlayed = perf.games;
                        item.playerWinRate = perf.getWinRate();
                        item.globalWinRate = meta.overallWinRate;
                        item.globalTier = meta.tierLabel;

                        double delta = item.playerWinRate - item.globalWinRate;
                        if (meta.isDeadHero || "D".equals(meta.tierLabel)) {
                            item.diagnosticTag = "DEAD TRAP";
                            item.isWarning = true;
                            item.replacementSuggestion = findBestMetaReplacement(meta, heroMap);
                        } else if (perf.games >= 10 && delta >= 4.0) {
                            item.diagnosticTag = "COMFORT ACE";
                            item.isWarning = false;
                            item.replacementSuggestion = String.format(Locale.US,
                                    "Keep picking! You outperform global average by +%.1f%% WR.", delta);
                        } else if (perf.games >= 8 && delta <= -4.0) {
                            item.diagnosticTag = "MMR DRAIN";
                            item.isWarning = true;
                            item.replacementSuggestion = findBestMetaReplacement(meta, heroMap);
                        } else {
                            item.diagnosticTag = meta.tierLabel + "-TIER PICK";
                            item.isWarning = false;
                            item.replacementSuggestion = String.format(Locale.US,
                                    "Solid %s pick (Global %.1f%% WR).", meta.getPrimaryRole(), meta.overallWinRate);
                        }
                        report.diagnostics.add(item);
                    }

                    postReport(report, callback);
                } catch (final Exception e) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (callback != null) {
                                callback.onAuditError("Network error while auditing Steam account: " + e.getMessage());
                            }
                        }
                    });
                }
            }
        });
    }

    private String findBestMetaReplacement(HeroMetaEntity weakHero, Map<Integer, HeroMetaEntity> heroMap) {
        String targetRole = weakHero.getPrimaryRole();
        HeroMetaEntity bestMatch = null;
        for (HeroMetaEntity candidate : heroMap.values()) {
            if (candidate.heroId == weakHero.heroId || candidate.isDeadHero) continue;
            if (candidate.rolesCsv.contains(targetRole)) {
                if (bestMatch == null || candidate.metaScore > bestMatch.metaScore) {
                    bestMatch = candidate;
                }
            }
        }
        if (bestMatch == null) {
            for (HeroMetaEntity candidate : heroMap.values()) {
                if (!candidate.isDeadHero && (bestMatch == null || candidate.metaScore > bestMatch.metaScore)) {
                    bestMatch = candidate;
                }
            }
        }
        if (bestMatch != null) {
            return String.format(Locale.US,
                    "Recommended Meta Swap: %s (%s-Tier • %.1f%% WR)",
                    bestMatch.localizedName, bestMatch.tierLabel, bestMatch.overallWinRate);
        }
        return "Switch to an S-Tier meta hero in your primary role.";
    }

    private void postReport(final SteamAuditReport report, final AuditCallback callback) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onAuditComplete(report);
                }
            }
        });
    }
}
