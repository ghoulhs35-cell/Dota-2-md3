package com.dotapulse.md3.model;

import com.google.gson.annotations.SerializedName;

public class PlayerRecentMatch {
    @SerializedName("match_id")
    public long matchId;

    @SerializedName("player_slot")
    public int playerSlot;

    @SerializedName("radiant_win")
    public boolean radiantWin;

    @SerializedName("duration")
    public int duration;

    @SerializedName("hero_id")
    public int heroId;

    @SerializedName("kills")
    public int kills;

    @SerializedName("deaths")
    public int deaths;

    @SerializedName("assists")
    public int assists;

    @SerializedName("xp_per_min")
    public int xpPerMin;

    @SerializedName("gold_per_min")
    public int goldPerMin;

    @SerializedName("hero_damage")
    public int heroDamage;

    @SerializedName("last_hits")
    public int lastHits;

    public boolean isWin() {
        boolean isRadiant = playerSlot < 128;
        return (isRadiant && radiantWin) || (!isRadiant && !radiantWin);
    }
}
