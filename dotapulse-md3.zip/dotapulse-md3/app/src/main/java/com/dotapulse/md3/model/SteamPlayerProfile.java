package com.dotapulse.md3.model;

import com.google.gson.annotations.SerializedName;

public class SteamPlayerProfile {
    @SerializedName("rank_tier")
    public Integer rankTier;

    @SerializedName("leaderboard_rank")
    public Integer leaderboardRank;

    @SerializedName("profile")
    public ProfileDetail profile;

    public static class ProfileDetail {
        @SerializedName("account_id")
        public long accountId;

        @SerializedName("personaname")
        public String personaName;

        @SerializedName("avatarfull")
        public String avatarFull;

        @SerializedName("steamid")
        public String steamId;
    }
}
