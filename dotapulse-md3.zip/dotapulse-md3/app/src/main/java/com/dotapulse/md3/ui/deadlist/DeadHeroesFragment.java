package com.dotapulse.md3.ui.deadlist;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dotapulse.md3.R;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class DeadHeroesFragment extends Fragment {

    public interface OnHeroRowClickListener {
        void onHeroRowClicked(HeroMetaEntity hero);
    }

    private List<HeroMetaEntity> allHeroes = new ArrayList<>();
    private boolean startInPatchLogMode = false;
    private OnHeroRowClickListener clickListener;
    private DeadRowAdapter adapter;
    private MaterialCardView cardHeader;
    private TextView tvTitle;
    private TextView tvSubtitle;

    public static DeadHeroesFragment newInstance(List<HeroMetaEntity> heroes,
                                                   boolean patchLogMode,
                                                   OnHeroRowClickListener listener) {
        DeadHeroesFragment fragment = new DeadHeroesFragment();
        if (heroes != null) {
            fragment.allHeroes = new ArrayList<>(heroes);
        }
        fragment.startInPatchLogMode = patchLogMode;
        fragment.clickListener = listener;
        return fragment;
    }

    public void updateHeroes(List<HeroMetaEntity> heroes) {
        this.allHeroes = heroes != null ? new ArrayList<>(heroes) : new ArrayList<HeroMetaEntity>();
        if (adapter != null) {
            applyMode(startInPatchLogMode);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dead_heroes, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        cardHeader = view.findViewById(R.id.cardDeadHeader);
        tvTitle = view.findViewById(R.id.tvDeadSectionTitle);
        tvSubtitle = view.findViewById(R.id.tvDeadSectionSubtitle);

        RecyclerView rv = view.findViewById(R.id.rvDeadHeroes);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new DeadRowAdapter();
        rv.setAdapter(adapter);

        MaterialButtonToggleGroup toggleGroup = view.findViewById(R.id.toggleDeadOrPatch);
        if (startInPatchLogMode) {
            toggleGroup.check(R.id.btnModePatchLog);
        } else {
            toggleGroup.check(R.id.btnModeDeadGraveyard);
        }

        toggleGroup.addOnButtonCheckedListener(new MaterialButtonToggleGroup.OnButtonCheckedListener() {
            @Override
            public void onButtonChecked(MaterialButtonToggleGroup group, int checkedId, boolean isChecked) {
                if (!isChecked) return;
                startInPatchLogMode = (checkedId == R.id.btnModePatchLog);
                applyMode(startInPatchLogMode);
            }
        });

        applyMode(startInPatchLogMode);
    }

    private void applyMode(boolean patchLogMode) {
        if (!isAdded()) return;
        List<HeroMetaEntity> filtered = new ArrayList<>();
        if (patchLogMode) {
            cardHeader.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_tertiaryContainer));
            cardHeader.setStrokeColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_tertiary));
            tvTitle.setTextColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_onTertiaryContainer));
            tvSubtitle.setTextColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_onTertiaryContainer));
            tvTitle.setText("Patch 7.42 Meta Shifts • High-MMR Delta");
            tvSubtitle.setText("Sorted by largest Immortal/Divine vs. All-Bracket win rate divergence.");

            filtered.addAll(allHeroes);
            Collections.sort(filtered, new Comparator<HeroMetaEntity>() {
                @Override
                public int compare(HeroMetaEntity a, HeroMetaEntity b) {
                    return Double.compare(Math.abs(b.winRateDelta), Math.abs(a.winRateDelta));
                }
            });
        } else {
            cardHeader.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_errorContainer));
            cardHeader.setStrokeColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_error));
            tvTitle.setTextColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_onErrorContainer));
            tvSubtitle.setTextColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_onErrorContainer));
            tvTitle.setText("Dead Heroes Graveyard • Patch 7.42");
            tvSubtitle.setText("Heroes below 46.5% weighted win rate and 3.5% pick rate or Meta Score < 34.");

            for (HeroMetaEntity h : allHeroes) {
                if (h.isDeadHero || "D".equals(h.tierLabel) || "C".equals(h.tierLabel)) {
                    filtered.add(h);
                }
            }
            Collections.sort(filtered, new Comparator<HeroMetaEntity>() {
                @Override
                public int compare(HeroMetaEntity a, HeroMetaEntity b) {
                    return Double.compare(a.metaScore, b.metaScore);
                }
            });
        }
        adapter.submit(filtered, patchLogMode);
    }

    private class DeadRowAdapter extends RecyclerView.Adapter<DeadRowAdapter.RowVH> {
        private final List<HeroMetaEntity> rows = new ArrayList<>();
        private boolean isPatchMode = false;

        void submit(List<HeroMetaEntity> data, boolean patchMode) {
            rows.clear();
            rows.addAll(data);
            this.isPatchMode = patchMode;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public RowVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_dead_hero_row, parent, false);
            return new RowVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull RowVH holder, int position) {
            final HeroMetaEntity hero = rows.get(position);
            Glide.with(holder.itemView.getContext())
                    .load(hero.getHeroPortraitUrl())
                    .placeholder(R.drawable.bg_hero_fallback_gradient)
                    .into(holder.ivAvatar);

            holder.tvName.setText(hero.localizedName + " (" + hero.getPrimaryRole() + ")");
            holder.tvStats.setText(String.format(Locale.US,
                    "WR %.1f%% • High-MMR %.1f%% • Pick %.1f%%",
                    hero.overallWinRate, hero.highMmrWinRate, hero.pickRate));

            if (isPatchMode) {
                boolean positive = hero.winRateDelta >= 0;
                holder.cardBadge.setCardBackgroundColor(ContextCompat.getColor(requireContext(),
                        positive ? R.color.md_theme_dark_tertiaryContainer : R.color.md_theme_dark_errorContainer));
                holder.tvBadge.setTextColor(ContextCompat.getColor(requireContext(),
                        positive ? R.color.md_theme_dark_onTertiaryContainer : R.color.md_theme_dark_onErrorContainer));
                holder.tvBadge.setText(String.format(Locale.US, "%s • %+.1f%%", hero.tierLabel, hero.winRateDelta));
            } else {
                holder.cardBadge.setCardBackgroundColor(ContextCompat.getColor(requireContext(),
                        hero.isDeadHero ? R.color.md_theme_dark_errorContainer : R.color.md_theme_dark_surfaceContainerHighest));
                holder.tvBadge.setTextColor(ContextCompat.getColor(requireContext(),
                        hero.isDeadHero ? R.color.md_theme_dark_onErrorContainer : R.color.md_theme_dark_onSurface));
                holder.tvBadge.setText(String.format(Locale.US, "%s • %.1f%%", hero.tierLabel, hero.overallWinRate));
            }

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (clickListener != null) {
                        clickListener.onHeroRowClicked(hero);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return rows.size();
        }

        class RowVH extends RecyclerView.ViewHolder {
            final ShapeableImageView ivAvatar;
            final TextView tvName;
            final TextView tvStats;
            final MaterialCardView cardBadge;
            final TextView tvBadge;

            RowVH(@NonNull View itemView) {
                super(itemView);
                ivAvatar = itemView.findViewById(R.id.ivRowHeroAvatar);
                tvName = itemView.findViewById(R.id.tvRowHeroName);
                tvStats = itemView.findViewById(R.id.tvRowHeroStats);
                cardBadge = itemView.findViewById(R.id.cardRowBadge);
                tvBadge = itemView.findViewById(R.id.tvRowBadgeText);
            }
        }
    }
}
