package com.dotapulse.md3.network;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class RetrofitClient {

    private static final String BASE_URL = "https://api.opendota.com/api/";
    private static volatile OpenDotaApiService instance;

    private RetrofitClient() {}

    public static OpenDotaApiService getApiService() {
        if (instance == null) {
            synchronized (RetrofitClient.class) {
                if (instance == null) {
                    OkHttpClient okHttpClient = new OkHttpClient.Builder()
                            .connectTimeout(15, TimeUnit.SECONDS)
                            .readTimeout(15, TimeUnit.SECONDS)
                            .writeTimeout(15, TimeUnit.SECONDS)
                            .addInterceptor(new Interceptor() {
                                @Override
                                public Response intercept(Chain chain) throws IOException {
                                    Request req = chain.request().newBuilder()
                                            .header("User-Agent", "DotaPulse-MD3-Android/1.0")
                                            .header("Accept", "application/json")
                                            .build();
                                    return chain.proceed(req);
                                }
                            })
                            .build();

                    Retrofit retrofit = new Retrofit.Builder()
                            .baseUrl(BASE_URL)
                            .client(okHttpClient)
                            .addConverterFactory(GsonConverterFactory.create())
                            .build();

                    instance = retrofit.create(OpenDotaApiService.class);
                }
            }
        }
        return instance;
    }
}
