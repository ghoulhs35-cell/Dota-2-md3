package com.dotapulse.md3;

import android.app.Application;
import com.google.android.material.color.DynamicColors;

public class DotaPulseApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        DynamicColors.applyToActivitiesIfAvailable(this);
    }
}
