package com.dotapulse.md3.ui.audit;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dotapulse.md3.R;
import com.dotapulse.md3.auth.SessionManager;
import com.dotapulse.md3.auth.SteamIdConverter;
import com.dotapulse.md3.engine.SteamAuditEngine;
import com.dotapulse.md3.model.SteamAuditReport;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SteamAuditFragment extends Fragment {

    public interface SteamAuthLauncher {
        void onLaunchSteamSignIn();
        void onSessionUpdated();
    }

    private SteamAuthLauncher authLauncher;
    private SessionManager sessionManager;
    private SteamAuditEngine auditEngine;

    private MaterialCardView cardSignInPrompt;
    private LinearProgressIndicator progressLoading;
    private MaterialCardView cardPrivateWarning;
    private LinearLayout layoutReportContent;

    private ShapeableImageView ivAvatar;
    private TextView tvPersona;
    private TextView tvIds;
    private TextView tvMetaAlignment;
    private LinearProgressIndicator progressMetaAlignment;
    private TextView tvDeadTrapRate;
    private TextView tvRecentWinRate;
    private AuditDiagnosticAdapter diagnosticAdapter;

    public static SteamAuditFragment newInstance(SteamAuthLauncher launcher) {
        SteamAuditFragment fragment = new SteamAuditFragment();
        fragment.authLauncher = launcher;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_steam_audit, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sessionManager = new SessionManager(requireContext());
        auditEngine = new SteamAuditEngine(requireContext());

        cardSignInPrompt = view.findViewById(R.id.cardAuditSignInPrompt);
        progressLoading = view.findViewById(R.id.progressAuditLoading);
        cardPrivateWarning = view.findViewById(R.id.cardPrivateDataWarning);
        layoutReportContent = view.findViewById(R.id.layoutAuditReportContent);

        ivAvatar = view.findViewById(R.id.ivAuditAvatar);
        tvPersona = view.findViewById(R.id.tvAuditPersona);
        tvIds = view.findViewById(R.id.tvAuditIds);
        tvMetaAlignment = view.findViewById(R.id.tvMetaAlignmentScore);
        progressMetaAlignment = view.findViewById(R.id.progressMetaAlignment);
        tvDeadTrapRate = view.findViewById(R.id.tvDeadTrapRate);
        tvRecentWinRate = view.findViewById(R.id.tvRecentWinRate);

        RecyclerView rvDiagnostics = view.findViewById(R.id.rvAuditHeroDiagnostics);
        rvDiagnostics.setLayoutManager(new LinearLayoutManager(requireContext()));
        diagnosticAdapter = new AuditDiagnosticAdapter();
        rvDiagnostics.setAdapter(diagnosticAdapter);

        MaterialButton btnSignIn = view.findViewById(R.id.btnAuditSteamSignIn);
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (authLauncher != null) {
                    authLauncher.onLaunchSteamSignIn();
                }
            }
        });

        final TextInputLayout tilManual = view.findViewById(R.id.tilAuditManualId);
        final TextInputEditText etManual = view.findViewById(R.id.etAuditManualId);
        MaterialButton btnManualSubmit = view.findViewById(R.id.btnAuditManualSubmit);
        btnManualSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String raw = etManual.getText() != null ? etManual.getText().toString() : "";
                long accountId32 = SteamIdConverter.parseToAccountId32(raw);
                if (accountId32 <= 0L) {
                    tilManual.setError("Invalid Friend ID or Steam URL");
                    return;
                }
                tilManual.setError(null);
                sessionManager.saveSession(accountId32,
                        String.valueOf(SteamIdConverter.toSteamId64(accountId32)),
                        "Player #" + accountId32, "");
                if (authLauncher != null) {
                    authLauncher.onSessionUpdated();
                }
                executeAuditForAccount(accountId32);
            }
        });

        MaterialButton btnSignOut = view.findViewById(R.id.btnAuditSignOut);
        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.clearSession();
                if (authLauncher != null) {
                    authLauncher.onSessionUpdated();
                }
                renderState();
            }
        });

        renderState();
    }

    public void renderState() {
        if (!isAdded() || sessionManager == null) return;
        if (sessionManager.isSignedIn()) {
            cardSignInPrompt.setVisibility(View.GONE);
            executeAuditForAccount(sessionManager.getAccountId32());
        } else {
            cardSignInPrompt.setVisibility(View.VISIBLE);
            progressLoading.setVisibility(View.GONE);
            cardPrivateWarning.setVisibility(View.GONE);
            layoutReportContent.setVisibility(View.GONE);
        }
    }

    public void executeAuditForAccount(long accountId32) {
        if (!isAdded()) return;
        cardSignInPrompt.setVisibility(View.GONE);
        cardPrivateWarning.setVisibility(View.GONE);
        progressLoading.setVisibility(View.VISIBLE);

        auditEngine.runAudit(accountId32, new SteamAuditEngine.AuditCallback() {
            @Override
            public void onAuditComplete(SteamAuditReport report) {
                if (!isAdded()) return;
                progressLoading.setVisibility(View.GONE);
                if (authLauncher != null) {
                    authLauncher.onSessionUpdated();
                }
                if (report.isPrivateProfile) {
                    cardPrivateWarning.setVisibility(View.VISIBLE);
                    layoutReportContent.setVisibility(View.GONE);
                    return;
                }

                cardPrivateWarning.setVisibility(View.GONE);
                layoutReportContent.setVisibility(View.VISIBLE);

                Glide.with(SteamAuditFragment.this)
                        .load(report.avatarUrl)
                        .placeholder(R.drawable.ic_steam_logo)
                        .error(R.drawable.ic_steam_logo)
                        .into(ivAvatar);

                tvPersona.setText(report.personaName);
                tvIds.setText(String.format(Locale.US,
                        "Account ID: %d • Career WR: %.1f%% (%dW–%dL)",
                        report.accountId32, report.overallWinRate, report.totalWins, report.totalLosses));

                tvMetaAlignment.setText(String.format(Locale.US,
                        "Meta Alignment Score: %d / 100", report.metaAlignmentScore));
                progressMetaAlignment.setProgress(report.metaAlignmentScore);

                tvDeadTrapRate.setText(String.format(Locale.US,
                        "Dead-Hero Trap Rate: %.0f%% of recent matches", report.deadHeroTrapRate));
                tvRecentWinRate.setText(String.format(Locale.US,
                        "Recent 20 WR: %.1f%% • Avg KDA: %.2f • %d GPM / %d XPM",
                        report.recent20WinRate, report.avgKda, report.avgGpm, report.avgXpm));

                diagnosticAdapter.submit(report.diagnostics);
            }

            @Override
            public void onAuditError(String message) {
                if (!isAdded()) return;
                progressLoading.setVisibility(View.GONE);
                cardPrivateWarning.setVisibility(View.VISIBLE);
            }
        });
    }

    private class AuditDiagnosticAdapter extends RecyclerView.Adapter<AuditDiagnosticAdapter.DiagVH> {
        private final List<SteamAuditReport.HeroAuditItem> items = new ArrayList<>();

        void submit(List<SteamAuditReport.HeroAuditItem> list) {
            items.clear();
            if (list != null) items.addAll(list);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public DiagVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_audit_hero_row, parent, false);
            return new DiagVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull DiagVH holder, int position) {
            SteamAuditReport.HeroAuditItem item = items.get(position);
            Glide.with(holder.itemView.getContext())
                    .load(item.heroPortraitUrl)
                    .placeholder(R.drawable.bg_hero_fallback_gradient)
                    .into(holder.ivAvatar);

            holder.tvName.setText(String.format(Locale.US, "%s (%d Games)", item.heroName, item.gamesPlayed));
            holder.tvPerf.setText(String.format(Locale.US,
                    "You: %.1f%% WR • Meta: %.1f%% (%s-Tier)",
                    item.playerWinRate, item.globalWinRate, item.globalTier));
            holder.tvTag.setText(item.diagnosticTag);
            holder.tvReplacement.setText(item.replacementSuggestion);

            if (item.isWarning) {
                holder.cardTag.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_errorContainer));
                holder.tvTag.setTextColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_onErrorContainer));
            } else {
                holder.cardTag.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_tertiaryContainer));
                holder.tvTag.setTextColor(ContextCompat.getColor(requireContext(), R.color.md_theme_dark_onTertiaryContainer));
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class DiagVH extends RecyclerView.ViewHolder {
            final ShapeableImageView ivAvatar;
            final TextView tvName;
            final TextView tvPerf;
            final MaterialCardView cardTag;
            final TextView tvTag;
            final TextView tvReplacement;

            DiagVH(@NonNull View itemView) {
                super(itemView);
                ivAvatar = itemView.findViewById(R.id.ivAuditHeroAvatar);
                tvName = itemView.findViewById(R.id.tvAuditHeroName);
                tvPerf = itemView.findViewById(R.id.tvAuditHeroPerf);
                cardTag = itemView.findViewById(R.id.cardAuditTag);
                tvTag = itemView.findViewById(R.id.tvAuditTag);
                tvReplacement = itemView.findViewById(R.id.tvAuditReplacement);
            }
        }
    }
}
