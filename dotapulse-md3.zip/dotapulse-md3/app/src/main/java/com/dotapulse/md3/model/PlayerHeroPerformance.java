package com.dotapulse.md3.model;

import com.google.gson.annotations.SerializedName;

public class PlayerHeroPerformance {
    @SerializedName("hero_id")
    public int heroId;

    @SerializedName("last_played")
    public long lastPlayed;

    @SerializedName("games")
    public int games;

    @SerializedName("win")
    public int win;

    @SerializedName("with_games")
    public int withGames;

    @SerializedName("with_win")
    public int withWin;

    @SerializedName("against_games")
    public int againstGames;

    @SerializedName("against_win")
    public int againstWin;

    public double getWinRate() {
        return games > 0 ? (win * 100.0) / games : 0.0;
    }
}
