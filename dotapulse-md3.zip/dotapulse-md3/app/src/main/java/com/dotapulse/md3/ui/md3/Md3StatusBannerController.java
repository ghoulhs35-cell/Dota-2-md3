package com.dotapulse.md3.ui.md3;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.dotapulse.md3.R;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.color.MaterialColors;

/**
 * Dynamically maps HeroMetaEntity tiers and Steam authentication states onto
 * Material Design 3 semantic tonal container roles.
 */
public final class Md3StatusBannerController {

    private final MaterialCardView cardStatusBanner;
    private final ImageView ivStatusIcon;
    private final TextView tvStatusText;
    private final MaterialCardView cardTierPill;
    private final TextView tvTierPill;
    private final MaterialCardView cardSteamAction;
    private final TextView tvSteamLabel;

    public Md3StatusBannerController(@NonNull View rootView) {
        this.cardStatusBanner = rootView.findViewById(R.id.cardMetaStatusBanner);
        this.ivStatusIcon = rootView.findViewById(R.id.ivStatusBannerIcon);
        this.tvStatusText = rootView.findViewById(R.id.tvStatusBannerText);
        this.cardTierPill = rootView.findViewById(R.id.cardTierPill);
        this.tvTierPill = rootView.findViewById(R.id.tvBannerTierPill);
        this.cardSteamAction = rootView.findViewById(R.id.cardSteamActionBanner);
        this.tvSteamLabel = rootView.findViewById(R.id.tvSteamBannerLabel);
    }

    public void bindHeroStatus(@NonNull HeroMetaEntity hero) {
        Context ctx = cardStatusBanner.getContext();
        int containerColor;
        int onContainerColor;
        int strokeColor;
        int pillBgColor;
        int onPillTextColor;

        if (hero.isDeadHero || "D".equals(hero.tierLabel)) {
            containerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorErrorContainer,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_errorContainer));
            onContainerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnErrorContainer,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_onErrorContainer));
            strokeColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorError,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_error));
            pillBgColor = strokeColor;
            onPillTextColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnError,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_onError));
        } else if ("S".equals(hero.tierLabel)) {
            containerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSecondaryContainer,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_secondaryContainer));
            onContainerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSecondaryContainer,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_onSecondaryContainer));
            strokeColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSecondary,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_secondary));
            pillBgColor = strokeColor;
            onPillTextColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSecondary,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_onSecondary));
        } else if ("A".equals(hero.tierLabel)) {
            containerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorTertiaryContainer,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_tertiaryContainer));
            onContainerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnTertiaryContainer,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_onTertiaryContainer));
            strokeColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorTertiary,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_tertiary));
            pillBgColor = strokeColor;
            onPillTextColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnTertiary,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_onTertiary));
        } else {
            containerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurfaceContainerHigh,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_surfaceContainerHigh));
            onContainerColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOnSurface,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_onSurface));
            strokeColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOutlineVariant,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_outlineVariant));
            pillBgColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurfaceContainerHighest,
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_surfaceContainerHighest));
            onPillTextColor = onContainerColor;
        }

        cardStatusBanner.setCardBackgroundColor(containerColor);
        cardStatusBanner.setStrokeColor(strokeColor);
        ivStatusIcon.setImageTintList(ColorStateList.valueOf(onContainerColor));
        tvStatusText.setTextColor(onContainerColor);
        tvStatusText.setText(hero.statusBannerTitle);

        cardTierPill.setCardBackgroundColor(pillBgColor);
        tvTierPill.setTextColor(onPillTextColor);
        tvTierPill.setText(hero.tierLabel);
    }

    public void bindSteamState(boolean isSignedIn, String personaName, View.OnClickListener listener) {
        if (isSignedIn && personaName != null && !personaName.isEmpty()) {
            tvSteamLabel.setText("Audit Steam Profile • " + personaName);
        } else {
            tvSteamLabel.setText(R.string.banner_steam_sign_in);
        }
        cardSteamAction.setOnClickListener(listener);
    }
}
