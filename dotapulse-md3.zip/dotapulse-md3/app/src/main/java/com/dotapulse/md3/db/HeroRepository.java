package com.dotapulse.md3.db;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.dotapulse.md3.engine.MetaClassifierEngine;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.dotapulse.md3.model.HeroStatsDto;
import com.dotapulse.md3.network.RetrofitClient;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Response;

public class HeroRepository {

    private static final long CACHE_TTL_MS = 1_800_000L; // 30 minutes
    private final Context appContext;
    private final HeroMetaDao dao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface HeroesCallback {
        void onHeroesLoaded(List<HeroMetaEntity> heroes, boolean fromNetwork);
    }

    public HeroRepository(Context context) {
        this.appContext = context.getApplicationContext();
        this.dao = AppDatabase.getInstance(appContext).heroMetaDao();
    }

    public void loadHeroes(final boolean forceRefresh, final HeroesCallback callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // 1. Seed offline dataset if Room is empty
                if (dao.countHeroes() == 0) {
                    List<HeroStatsDto> seedDtos = readSeedAsset();
                    List<HeroMetaEntity> seeded = MetaClassifierEngine.classifyAll(seedDtos, System.currentTimeMillis());
                    dao.insertAll(seeded);
                }

                final List<HeroMetaEntity> cached = dao.getAllHeroesByMetaScore();
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (callback != null) {
                            callback.onHeroesLoaded(cached, false);
                        }
                    }
                });

                // 2. Stale-while-revalidate refresh from OpenDota
                Long latestTs = dao.getLatestTimestamp();
                boolean isStale = latestTs == null || (System.currentTimeMillis() - latestTs) > CACHE_TTL_MS;
                if (forceRefresh || isStale) {
                    try {
                        Response<List<HeroStatsDto>> response = RetrofitClient.getApiService().getHeroStats().execute();
                        if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                            Set<Integer> watchlistedIds = new HashSet<>();
                            Set<Integer> likedIds = new HashSet<>();
                            for (HeroMetaEntity existing : cached) {
                                if (existing.isWatchlisted) watchlistedIds.add(existing.heroId);
                                if (existing.isLiked) likedIds.add(existing.heroId);
                            }

                            List<HeroMetaEntity> fresh = MetaClassifierEngine.classifyAll(
                                    response.body(), System.currentTimeMillis());
                            for (HeroMetaEntity item : fresh) {
                                item.isWatchlisted = watchlistedIds.contains(item.heroId);
                                item.isLiked = likedIds.contains(item.heroId);
                            }
                            dao.insertAll(fresh);
                            final List<HeroMetaEntity> updated = dao.getAllHeroesByMetaScore();
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (callback != null) {
                                        callback.onHeroesLoaded(updated, true);
                                    }
                                }
                            });
                        }
                    } catch (Exception ignored) {
                        // Offline or rate-limited; cached/seed data remains active
                    }
                }
            }
        });
    }

    public void setWatchlisted(final int heroId, final boolean watchlisted) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                dao.updateWatchlist(heroId, watchlisted);
            }
        });
    }

    public void setLiked(final int heroId, final boolean liked) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                dao.updateLiked(heroId, liked);
            }
        });
    }

    public Map<Integer, HeroMetaEntity> getHeroMapBlocking() {
        if (dao.countHeroes() == 0) {
            List<HeroStatsDto> seedDtos = readSeedAsset();
            dao.insertAll(MetaClassifierEngine.classifyAll(seedDtos, System.currentTimeMillis()));
        }
        List<HeroMetaEntity> list = dao.getAllHeroesByMetaScore();
        Map<Integer, HeroMetaEntity> map = new HashMap<>();
        for (HeroMetaEntity e : list) {
            map.put(e.heroId, e);
        }
        return map;
    }

    private List<HeroStatsDto> readSeedAsset() {
        try (InputStream is = appContext.getAssets().open("seed_hero_stats.json");
             BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            Type listType = new TypeToken<List<HeroStatsDto>>() {}.getType();
            return new Gson().fromJson(reader, listType);
        } catch (Exception e) {
            return java.util.Collections.emptyList();
        }
    }
}
