package com.dotapulse.md3.model;

import java.util.ArrayList;
import java.util.List;

public class SteamAuditReport {
    public long accountId32;
    public String steamId64;
    public String personaName;
    public String avatarUrl;
    public boolean isPrivateProfile;

    public int totalWins;
    public int totalLosses;
    public double overallWinRate;
    public double recent20WinRate;
    public int metaAlignmentScore;
    public double deadHeroTrapRate;

    public int avgGpm;
    public int avgXpm;
    public double avgKda;

    public final List<HeroAuditItem> diagnostics = new ArrayList<>();

    public static class HeroAuditItem {
        public int heroId;
        public String heroName;
        public String heroPortraitUrl;
        public int gamesPlayed;
        public double playerWinRate;
        public double globalWinRate;
        public String globalTier;
        public String diagnosticTag;
        public boolean isWarning;
        public String replacementSuggestion;
    }
}
