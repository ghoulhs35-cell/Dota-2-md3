package com.dotapulse.md3.engine;

import com.dotapulse.md3.model.HeroMetaEntity;
import com.dotapulse.md3.model.HeroStatsDto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Classifies Dota 2 heroes into Meta Kings (S/A) vs. Dead Heroes (D) using
 * bracket-weighted win rates, normalized pick rates, and pro contest presence.
 */
public final class MetaClassifierEngine {

    private MetaClassifierEngine() {}

    public static List<HeroMetaEntity> classifyAll(List<HeroStatsDto> rawHeroes, long timestamp) {
        if (rawHeroes == null || rawHeroes.isEmpty()) {
            return Collections.emptyList();
        }

        long totalAllHeroPicks = 0L;
        long maxProContest = 1L;
        for (HeroStatsDto dto : rawHeroes) {
            totalAllHeroPicks += dto.getTotalPubPicks();
            long contest = (long) dto.proPick + (long) dto.proBan;
            if (contest > maxProContest) {
                maxProContest = contest;
            }
        }
        double estimatedTotalMatches = Math.max(1.0, totalAllHeroPicks / 10.0);

        List<HeroMetaEntity> entities = new ArrayList<>(rawHeroes.size());
        for (HeroStatsDto dto : rawHeroes) {
            long pubPicks = dto.getTotalPubPicks();
            long pubWins = dto.getTotalPubWins();
            double overallWr = pubPicks > 0 ? (pubWins * 100.0) / pubPicks : 50.0;

            long highMmrPicks = (long) dto.bracket7Pick + (long) dto.bracket8Pick;
            long highMmrWins = (long) dto.bracket7Win + (long) dto.bracket8Win;
            double highMmrWr = highMmrPicks > 0 ? (highMmrWins * 100.0) / highMmrPicks : overallWr;

            double heraldCrusaderWr = calcBracketWr(
                    (long) dto.bracket1Pick + dto.bracket2Pick + dto.bracket3Pick,
                    (long) dto.bracket1Win + dto.bracket2Win + dto.bracket3Win, overallWr);
            double archonLegendWr = calcBracketWr(
                    (long) dto.bracket4Pick + dto.bracket5Pick,
                    (long) dto.bracket4Win + dto.bracket5Win, overallWr);
            double ancientDivineWr = calcBracketWr(
                    (long) dto.bracket6Pick + dto.bracket7Pick,
                    (long) dto.bracket6Win + dto.bracket7Win, highMmrWr);
            double immortalWr = calcBracketWr(dto.bracket8Pick, dto.bracket8Win, highMmrWr);

            double pickRate = (pubPicks * 100.0) / estimatedTotalMatches;
            double proContestRate = ((dto.proPick + dto.proBan) * 100.0) / maxProContest;
            double weightedWr = (0.45 * overallWr) + (0.55 * highMmrWr);
            double wrDelta = highMmrWr - overallWr;

            double rawScore = 50.0
                    + ((weightedWr - 50.0) * 6.5)
                    + Math.min(12.0, pickRate * 0.65)
                    + Math.min(10.0, proContestRate * 0.12);
            double metaScore = Math.max(0.0, Math.min(100.0, rawScore));

            String tierLabel;
            String statusBannerTitle;
            boolean isDead = false;

            if (metaScore >= 72.0 || (weightedWr >= 53.2 && pickRate >= 4.0)) {
                tierLabel = "S";
                statusBannerTitle = String.format(Locale.US, "Status: Meta King • S-Tier (%.1f%% WR)", weightedWr);
            } else if (metaScore >= 60.0) {
                tierLabel = "A";
                statusBannerTitle = String.format(Locale.US, "Status: Strong Meta • A-Tier (%.1f%% WR)", weightedWr);
            } else if (metaScore >= 46.0) {
                tierLabel = "B";
                statusBannerTitle = String.format(Locale.US, "Status: Viable Pick • B-Tier (%.1f%% WR)", weightedWr);
            } else if (metaScore >= 34.0 && !(weightedWr < 46.5 && pickRate < 3.5)) {
                tierLabel = "C";
                statusBannerTitle = String.format(Locale.US, "Status: Weak Niche • C-Tier (%.1f%% WR)", weightedWr);
            } else {
                tierLabel = "D";
                isDead = true;
                statusBannerTitle = String.format(Locale.US, "Status: Dead Hero • D-Tier (%.1f%% WR)", weightedWr);
            }

            String primaryRole = (dto.roles != null && !dto.roles.isEmpty()) ? dto.roles.get(0) : "Flex";
            String verdict = buildVerdict(primaryRole, weightedWr, pickRate, proContestRate, isDead);

            HeroMetaEntity entity = new HeroMetaEntity();
            entity.heroId = dto.id;
            entity.localizedName = dto.localizedName != null ? dto.localizedName : "Unknown Hero";
            entity.shortName = dto.name != null ? dto.name.replace("npc_dota_hero_", "") : "axe";
            entity.primaryAttr = dto.primaryAttr != null ? dto.primaryAttr.toUpperCase(Locale.US) : "ALL";
            entity.attackType = dto.attackType != null ? dto.attackType : "Melee";
            entity.rolesCsv = dto.roles != null && !dto.roles.isEmpty() ? String.join(" • ", dto.roles) : "Flex";
            entity.overallWinRate = overallWr;
            entity.highMmrWinRate = highMmrWr;
            entity.heraldCrusaderWr = heraldCrusaderWr;
            entity.archonLegendWr = archonLegendWr;
            entity.ancientDivineWr = ancientDivineWr;
            entity.immortalWr = immortalWr;
            entity.pickRate = pickRate;
            entity.proContestRate = proContestRate;
            entity.winRateDelta = wrDelta;
            entity.metaScore = metaScore;
            entity.tierLabel = tierLabel;
            entity.isDeadHero = isDead;
            entity.statusBannerTitle = statusBannerTitle;
            entity.verdictSummary = verdict;
            entity.totalPubPicks = pubPicks;
            entity.proMatchesSample = dto.proPick + dto.proBan;
            entity.lastUpdatedEpoch = timestamp;
            entities.add(entity);
        }

        Collections.sort(entities, new Comparator<HeroMetaEntity>() {
            @Override
            public int compare(HeroMetaEntity a, HeroMetaEntity b) {
                return Double.compare(b.metaScore, a.metaScore);
            }
        });
        return entities;
    }

    private static double calcBracketWr(long picks, long wins, double fallback) {
        return picks > 0 ? (wins * 100.0) / picks : fallback;
    }

    private static String buildVerdict(String role, double wr, double pr, double proRate, boolean dead) {
        if (dead) {
            return String.format(Locale.US,
                    "WR %.1f%% • Pick %.1f%% • Pro %.0f%% — Outpaced in current patch; avoid unless last-pick cheese.",
                    wr, pr, proRate);
        }
        return String.format(Locale.US,
                "WR %.1f%% • Pick %.1f%% • Pro %.0f%% — High-tempo %s dominating current patch drafts.",
                wr, pr, proRate, role.toLowerCase(Locale.US));
    }
}
