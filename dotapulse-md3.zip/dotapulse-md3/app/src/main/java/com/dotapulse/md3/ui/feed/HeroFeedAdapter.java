package com.dotapulse.md3.ui.feed;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dotapulse.md3.R;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HeroFeedAdapter extends RecyclerView.Adapter<HeroFeedAdapter.HeroViewHolder> {

    public interface HeroActionListener {
        void onToggleWatchlist(HeroMetaEntity hero, int position);
        void onToggleLike(HeroMetaEntity hero, int position);
        void onOpenDetailSheet(HeroMetaEntity hero);
    }

    private final List<HeroMetaEntity> items = new ArrayList<>();
    private final HeroActionListener listener;

    public HeroFeedAdapter(HeroActionListener listener) {
        this.listener = listener;
    }

    public void submitList(List<HeroMetaEntity> newItems) {
        items.clear();
        if (newItems != null) {
            items.addAll(newItems);
        }
        notifyDataSetChanged();
    }

    public HeroMetaEntity getItemAt(int position) {
        if (position >= 0 && position < items.size()) {
            return items.get(position);
        }
        return null;
    }

    @NonNull
    @Override
    public HeroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_hero_feed_card, parent, false);
        return new HeroViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final HeroViewHolder holder, int position) {
        final HeroMetaEntity hero = items.get(position);
        final Context ctx = holder.itemView.getContext();

        Glide.with(ctx)
                .load(hero.getHeroPortraitUrl())
                .placeholder(R.drawable.bg_hero_fallback_gradient)
                .error(R.drawable.bg_hero_fallback_gradient)
                .centerCrop()
                .into(holder.ivHeroBackdrop);

        Glide.with(ctx)
                .load(hero.getHeroIconUrl())
                .placeholder(R.drawable.ic_launcher_foreground)
                .error(R.drawable.ic_launcher_foreground)
                .into(holder.ivHeroSquircleAvatar);

        Glide.with(ctx)
                .load(hero.getHeroIconUrl())
                .placeholder(R.drawable.ic_launcher_foreground)
                .error(R.drawable.ic_launcher_foreground)
                .into(holder.ivSpinningDisc);

        holder.ensureDiscRotation();

        if (hero.isDeadHero) {
            holder.tvWatermarkStamp.setText(String.format(Locale.US, "DEAD TIER • %.1f%% PICK", hero.pickRate));
        } else {
            holder.tvWatermarkStamp.setText(hero.primaryAttr + " • PATCH 7.42");
        }

        holder.tvHeroTitle.setText(hero.localizedName + " • " + hero.getPrimaryRole());
        holder.tvMetaVerdict.setText(hero.verdictSummary);

        // Tabular telemetry counters formatted cleanly
        holder.tvHeartCount.setText(formatCompactCount(hero.totalPubPicks / 6L));
        holder.tvMatchupsCount.setText(String.valueOf(Math.max(12, hero.proMatchesSample)));
        holder.tvBookmarkCount.setText(String.valueOf(Math.max(100, Math.round(hero.metaScore * 110))));
        holder.tvShareCount.setText(formatCompactCount(Math.max(1200L, Math.round(hero.pickRate * 1750))));

        // Watchlist badge state
        if (hero.isWatchlisted) {
            holder.cardWatchlistMiniBadge.setCardBackgroundColor(
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_tertiary));
            holder.ivWatchlistMiniIcon.setImageResource(R.drawable.ic_check);
            holder.ivWatchlistMiniIcon.setImageTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.md_theme_dark_onTertiary)));
            holder.btnActionBookmark.setIconTint(
                    ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.md_theme_dark_secondary)));
        } else {
            holder.cardWatchlistMiniBadge.setCardBackgroundColor(
                    ContextCompat.getColor(ctx, R.color.md_theme_dark_primary));
            holder.ivWatchlistMiniIcon.setImageResource(R.drawable.ic_add_plus);
            holder.ivWatchlistMiniIcon.setImageTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.md_theme_dark_onPrimary)));
            holder.btnActionBookmark.setIconTint(
                    ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.md_theme_dark_onSurface)));
        }

        // Heart upvote state
        if (hero.isLiked) {
            holder.btnActionHeart.setIconTint(
                    ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.md_theme_dark_error)));
        } else {
            holder.btnActionHeart.setIconTint(
                    ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.md_theme_dark_onSurface)));
        }

        // Bottom-left MD3 AssistChip tags
        holder.chipTagMeta.setText("#dota2meta");
        holder.chipTagTier.setText("#tier" + hero.tierLabel);
        holder.chipTagAttr.setText("#" + hero.primaryAttr.toLowerCase(Locale.US));

        View.OnClickListener watchlistClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && listener != null) {
                    listener.onToggleWatchlist(items.get(pos), pos);
                }
            }
        };
        holder.layoutHeroAvatarBadge.setOnClickListener(watchlistClick);
        holder.btnActionBookmark.setOnClickListener(watchlistClick);

        holder.btnActionHeart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && listener != null) {
                    listener.onToggleLike(items.get(pos), pos);
                }
            }
        });

        View.OnClickListener detailClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = holder.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && listener != null) {
                    listener.onOpenDetailSheet(items.get(pos));
                }
            }
        };
        holder.btnActionMatchups.setOnClickListener(detailClick);
        holder.chipTagMore.setOnClickListener(detailClick);

        holder.btnActionShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareHeroSummary(ctx, hero);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private String formatCompactCount(long value) {
        if (value >= 1_000_000L) {
            return String.format(Locale.US, "%.1fM", value / 1_000_000.0);
        } else if (value >= 1_000L) {
            return String.format(Locale.US, "%.1fK", value / 1_000.0);
        }
        return String.valueOf(value);
    }

    private void shareHeroSummary(Context ctx, HeroMetaEntity hero) {
        String shareBody = String.format(Locale.US,
                "DotaPulse MD3 • %s (%s-Tier)
%s
%s",
                hero.localizedName,
                hero.tierLabel,
                hero.statusBannerTitle,
                hero.verdictSummary);
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Dota 2 Meta Telemetry: " + hero.localizedName);
        sendIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
        ctx.startActivity(Intent.createChooser(sendIntent, "Share Hero Meta Card"));
    }

    static class HeroViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivHeroBackdrop;
        final TextView tvWatermarkStamp;
        final FrameLayout layoutHeroAvatarBadge;
        final ShapeableImageView ivHeroSquircleAvatar;
        final MaterialCardView cardWatchlistMiniBadge;
        final ImageView ivWatchlistMiniIcon;
        final MaterialButton btnActionHeart;
        final TextView tvHeartCount;
        final MaterialButton btnActionMatchups;
        final TextView tvMatchupsCount;
        final MaterialButton btnActionBookmark;
        final TextView tvBookmarkCount;
        final MaterialButton btnActionShare;
        final TextView tvShareCount;
        final ShapeableImageView ivSpinningDisc;
        final TextView tvHeroTitle;
        final TextView tvMetaVerdict;
        final Chip chipTagMeta;
        final Chip chipTagTier;
        final Chip chipTagAttr;
        final Chip chipTagMore;
        private ObjectAnimator discAnimator;

        HeroViewHolder(@NonNull View itemView) {
            super(itemView);
            ivHeroBackdrop = itemView.findViewById(R.id.ivHeroBackdrop);
            tvWatermarkStamp = itemView.findViewById(R.id.tvWatermarkStamp);
            layoutHeroAvatarBadge = itemView.findViewById(R.id.layoutHeroAvatarBadge);
            ivHeroSquircleAvatar = itemView.findViewById(R.id.ivHeroSquircleAvatar);
            cardWatchlistMiniBadge = itemView.findViewById(R.id.cardWatchlistMiniBadge);
            ivWatchlistMiniIcon = itemView.findViewById(R.id.ivWatchlistMiniIcon);
            btnActionHeart = itemView.findViewById(R.id.btnActionHeart);
            tvHeartCount = itemView.findViewById(R.id.tvHeartCount);
            btnActionMatchups = itemView.findViewById(R.id.btnActionMatchups);
            tvMatchupsCount = itemView.findViewById(R.id.tvMatchupsCount);
            btnActionBookmark = itemView.findViewById(R.id.btnActionBookmark);
            tvBookmarkCount = itemView.findViewById(R.id.tvBookmarkCount);
            btnActionShare = itemView.findViewById(R.id.btnActionShare);
            tvShareCount = itemView.findViewById(R.id.tvShareCount);
            ivSpinningDisc = itemView.findViewById(R.id.ivSpinningDisc);
            tvHeroTitle = itemView.findViewById(R.id.tvHeroTitle);
            tvMetaVerdict = itemView.findViewById(R.id.tvMetaVerdict);
            chipTagMeta = itemView.findViewById(R.id.chipTagMeta);
            chipTagTier = itemView.findViewById(R.id.chipTagTier);
            chipTagAttr = itemView.findViewById(R.id.chipTagAttr);
            chipTagMore = itemView.findViewById(R.id.chipTagMore);
        }

        void ensureDiscRotation() {
            if (discAnimator == null) {
                discAnimator = ObjectAnimator.ofFloat(ivSpinningDisc, View.ROTATION, 0f, 360f);
                discAnimator.setDuration(14000L);
                discAnimator.setRepeatCount(ValueAnimator.INFINITE);
                discAnimator.setInterpolator(new LinearInterpolator());
                discAnimator.start();
            } else if (!discAnimator.isRunning()) {
                discAnimator.start();
            }
        }
    }
}
