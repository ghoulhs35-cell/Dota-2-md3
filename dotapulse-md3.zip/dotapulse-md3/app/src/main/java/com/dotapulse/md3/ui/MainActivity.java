package com.dotapulse.md3.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.dotapulse.md3.R;
import com.dotapulse.md3.auth.SessionManager;
import com.dotapulse.md3.auth.SteamIdConverter;
import com.dotapulse.md3.auth.SteamOpenIdAuthActivity;
import com.dotapulse.md3.db.HeroRepository;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.dotapulse.md3.ui.audit.SteamAuditFragment;
import com.dotapulse.md3.ui.compare.HeroCompareBottomSheet;
import com.dotapulse.md3.ui.deadlist.DeadHeroesFragment;
import com.dotapulse.md3.ui.feed.HeroDetailBottomSheet;
import com.dotapulse.md3.ui.feed.HeroFeedAdapter;
import com.dotapulse.md3.ui.md3.Md3StatusBannerController;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private HeroRepository heroRepository;
    private SessionManager sessionManager;
    private Md3StatusBannerController bannerController;

    private ViewPager2 heroFeedViewPager;
    private FrameLayout secondaryFragmentContainer;
    private View includeStatusBanners;
    private MaterialCardView cardSearchOverlay;
    private EditText etSearchHero;
    private TabLayout topTabLayout;
    private BottomNavigationView bottomNavBar;

    private HeroFeedAdapter feedAdapter;
    private final List<HeroMetaEntity> allHeroes = new ArrayList<>();
    private final List<HeroMetaEntity> visibleHeroes = new ArrayList<>();

    private int activeTopTab = 2; // 0 = Dead Pool, 1 = Watchlist, 2 = Meta Feed
    private boolean liveHighMmrOnly = false;
    private int activeFilterChipId = R.id.chipFilterAll;
    private String searchQuery = "";

    private final ActivityResultLauncher<Intent> steamAuthLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            syncSteamBannerState();
                            if (result.getResultCode() == RESULT_OK) {
                                bottomNavBar.setSelectedItemId(R.id.nav_steam_audit);
                            }
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);

        heroRepository = new HeroRepository(this);
        sessionManager = new SessionManager(this);

        heroFeedViewPager = findViewById(R.id.heroFeedViewPager);
        secondaryFragmentContainer = findViewById(R.id.secondaryFragmentContainer);
        includeStatusBanners = findViewById(R.id.includeStatusBanners);
        cardSearchOverlay = findViewById(R.id.cardSearchFilterOverlay);
        etSearchHero = findViewById(R.id.etSearchHero);
        topTabLayout = findViewById(R.id.topTabLayout);
        bottomNavBar = findViewById(R.id.bottomNavBar);

        bannerController = new Md3StatusBannerController(includeStatusBanners);

        applyEdgeToEdgeInsets();
        setupTopNavigation();
        setupSearchAndFilters();
        setupVerticalFeed();
        setupBottomNavigation();
        syncSteamBannerState();

        heroRepository.loadHeroes(false, new HeroRepository.HeroesCallback() {
            @Override
            public void onHeroesLoaded(List<HeroMetaEntity> heroes, boolean fromNetwork) {
                allHeroes.clear();
                allHeroes.addAll(heroes);
                applyFeedFilterAndSort();
            }
        });
    }

    private void applyEdgeToEdgeInsets() {
        final View topNav = findViewById(R.id.includeTopNav);
        final View bottomNavContainer = findViewById(R.id.includeBottomNav);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainRootContainer),
                new androidx.core.view.OnApplyWindowInsetsListener() {
                    @NonNull
                    @Override
                    public WindowInsetsCompat onApplyWindowInsets(@NonNull View v, @NonNull WindowInsetsCompat insets) {
                        Insets sysBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                        topNav.setPadding(topNav.getPaddingLeft(), sysBars.top,
                                topNav.getPaddingRight(), topNav.getPaddingBottom());
                        bottomNavContainer.setPadding(0, 0, 0, sysBars.bottom);
                        return insets;
                    }
                });
    }

    private void setupTopNavigation() {
        TabLayout.Tab defaultTab = topTabLayout.getTabAt(2);
        if (defaultTab != null) {
            defaultTab.select();
        }

        topTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                activeTopTab = tab.getPosition();
                showMainFeedViewport();
                if (bottomNavBar.getSelectedItemId() != R.id.nav_meta_feed) {
                    bottomNavBar.setSelectedItemId(R.id.nav_meta_feed);
                }
                applyFeedFilterAndSort();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                showMainFeedViewport();
            }
        });

        final Chip chipLive = findViewById(R.id.chipLiveFilter);
        chipLive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                liveHighMmrOnly = !liveHighMmrOnly;
                chipLive.setText(liveHighMmrOnly ? "IMMORTAL" : getString(R.string.chip_live_label));
                applyFeedFilterAndSort();
            }
        });

        MaterialButton btnSearchToggle = findViewById(R.id.btnSearchToggle);
        btnSearchToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean show = cardSearchOverlay.getVisibility() != View.VISIBLE;
                cardSearchOverlay.setVisibility(show ? View.VISIBLE : View.GONE);
            }
        });
    }

    private void setupSearchAndFilters() {
        MaterialButton btnCloseSearch = findViewById(R.id.btnCloseSearch);
        btnCloseSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etSearchHero.setText("");
                searchQuery = "";
                cardSearchOverlay.setVisibility(View.GONE);
                applyFeedFilterAndSort();
            }
        });

        etSearchHero.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s != null ? s.toString().trim().toLowerCase(Locale.US) : "";
                applyFeedFilterAndSort();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        ChipGroup chipGroupFilters = findViewById(R.id.chipGroupFilters);
        chipGroupFilters.setOnCheckedStateChangeListener(new ChipGroup.OnCheckedStateChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull ChipGroup group, @NonNull List<Integer> checkedIds) {
                if (!checkedIds.isEmpty()) {
                    activeFilterChipId = checkedIds.get(0);
                    applyFeedFilterAndSort();
                }
            }
        });
    }

    private void setupVerticalFeed() {
        feedAdapter = new HeroFeedAdapter(new HeroFeedAdapter.HeroActionListener() {
            @Override
            public void onToggleWatchlist(HeroMetaEntity hero, int position) {
                hero.isWatchlisted = !hero.isWatchlisted;
                heroRepository.setWatchlisted(hero.heroId, hero.isWatchlisted);
                feedAdapter.notifyItemChanged(position);
            }

            @Override
            public void onToggleLike(HeroMetaEntity hero, int position) {
                hero.isLiked = !hero.isLiked;
                heroRepository.setLiked(hero.heroId, hero.isLiked);
                feedAdapter.notifyItemChanged(position);
            }

            @Override
            public void onOpenDetailSheet(HeroMetaEntity hero) {
                openHeroDetailSheet(hero);
            }
        });

        heroFeedViewPager.setAdapter(feedAdapter);
        heroFeedViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                HeroMetaEntity current = feedAdapter.getItemAt(position);
                if (current != null) {
                    bannerController.bindHeroStatus(current);
                }
            }
        });
    }

    private void setupBottomNavigation() {
        BadgeDrawable patchBadge = bottomNavBar.getOrCreateBadge(R.id.nav_patch_log);
        patchBadge.setNumber(1);
        patchBadge.setVisible(true);

        bottomNavBar.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.nav_meta_feed) {
                    showMainFeedViewport();
                    return true;
                } else if (id == R.id.nav_dead_list) {
                    showSecondaryFragment(DeadHeroesFragment.newInstance(
                            allHeroes, false, new DeadHeroesFragment.OnHeroRowClickListener() {
                                @Override
                                public void onHeroRowClicked(HeroMetaEntity hero) {
                                    openHeroDetailSheet(hero);
                                }
                            }));
                    return true;
                } else if (id == R.id.nav_compare) {
                    HeroCompareBottomSheet.newInstance(allHeroes, new HeroCompareBottomSheet.QuickAuditCallback() {
                        @Override
                        public void onQuickAuditRequested(long accountId32) {
                            sessionManager.saveSession(accountId32,
                                    String.valueOf(SteamIdConverter.toSteamId64(accountId32)),
                                    "Player #" + accountId32, "");
                            syncSteamBannerState();
                            bottomNavBar.setSelectedItemId(R.id.nav_steam_audit);
                        }
                    }).show(getSupportFragmentManager(), "compare_sheet");
                    return false;
                } else if (id == R.id.nav_patch_log) {
                    BadgeDrawable badge = bottomNavBar.getBadge(R.id.nav_patch_log);
                    if (badge != null) {
                        badge.setVisible(false);
                    }
                    showSecondaryFragment(DeadHeroesFragment.newInstance(
                            allHeroes, true, new DeadHeroesFragment.OnHeroRowClickListener() {
                                @Override
                                public void onHeroRowClicked(HeroMetaEntity hero) {
                                    openHeroDetailSheet(hero);
                                }
                            }));
                    return true;
                } else if (id == R.id.nav_steam_audit) {
                    showSecondaryFragment(SteamAuditFragment.newInstance(new SteamAuditFragment.SteamAuthLauncher() {
                        @Override
                        public void onLaunchSteamSignIn() {
                            launchSteamOpenId();
                        }

                        @Override
                        public void onSessionUpdated() {
                            syncSteamBannerState();
                        }
                    }));
                    return true;
                }
                return false;
            }
        });
    }

    private void showMainFeedViewport() {
        secondaryFragmentContainer.setVisibility(View.GONE);
        heroFeedViewPager.setVisibility(View.VISIBLE);
        includeStatusBanners.setVisibility(View.VISIBLE);
    }

    private void showSecondaryFragment(Fragment fragment) {
        heroFeedViewPager.setVisibility(View.GONE);
        includeStatusBanners.setVisibility(View.GONE);
        cardSearchOverlay.setVisibility(View.GONE);
        secondaryFragmentContainer.setVisibility(View.VISIBLE);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.secondaryFragmentContainer, fragment)
                .commit();
    }

    private void applyFeedFilterAndSort() {
        visibleHeroes.clear();
        for (HeroMetaEntity h : allHeroes) {
            if (activeTopTab == 0 && !(h.isDeadHero || "D".equals(h.tierLabel))) {
                continue;
            }
            if (activeTopTab == 1 && !h.isWatchlisted) {
                continue;
            }
            if (!matchesChipFilter(h)) {
                continue;
            }
            if (!searchQuery.isEmpty()) {
                boolean matchName = h.localizedName.toLowerCase(Locale.US).contains(searchQuery);
                boolean matchRole = h.rolesCsv.toLowerCase(Locale.US).contains(searchQuery);
                if (!matchName && !matchRole) continue;
            }
            visibleHeroes.add(h);
        }

        if (visibleHeroes.isEmpty() && !allHeroes.isEmpty()) {
            visibleHeroes.addAll(allHeroes);
        }

        if (activeTopTab == 0) {
            Collections.sort(visibleHeroes, new Comparator<HeroMetaEntity>() {
                @Override
                public int compare(HeroMetaEntity a, HeroMetaEntity b) {
                    return Double.compare(a.metaScore, b.metaScore);
                }
            });
        } else if (liveHighMmrOnly) {
            Collections.sort(visibleHeroes, new Comparator<HeroMetaEntity>() {
                @Override
                public int compare(HeroMetaEntity a, HeroMetaEntity b) {
                    return Double.compare(b.highMmrWinRate, a.highMmrWinRate);
                }
            });
        } else {
            Collections.sort(visibleHeroes, new Comparator<HeroMetaEntity>() {
                @Override
                public int compare(HeroMetaEntity a, HeroMetaEntity b) {
                    return Double.compare(b.metaScore, a.metaScore);
                }
            });
        }

        feedAdapter.submitList(visibleHeroes);
        if (!visibleHeroes.isEmpty()) {
            heroFeedViewPager.setCurrentItem(0, false);
            bannerController.bindHeroStatus(visibleHeroes.get(0));
        }
    }

    private boolean matchesChipFilter(HeroMetaEntity h) {
        if (activeFilterChipId == R.id.chipFilterCarry) {
            return h.rolesCsv.contains("Carry");
        } else if (activeFilterChipId == R.id.chipFilterMid) {
            return h.rolesCsv.contains("Nuker") || h.rolesCsv.contains("Escape");
        } else if (activeFilterChipId == R.id.chipFilterOfflane) {
            return h.rolesCsv.contains("Durable") || h.rolesCsv.contains("Initiator");
        } else if (activeFilterChipId == R.id.chipFilterSupport) {
            return h.rolesCsv.contains("Support");
        } else if (activeFilterChipId == R.id.chipFilterSTier) {
            return "S".equals(h.tierLabel);
        } else if (activeFilterChipId == R.id.chipFilterDeadOnly) {
            return h.isDeadHero || "D".equals(h.tierLabel);
        }
        return true;
    }

    private void openHeroDetailSheet(final HeroMetaEntity hero) {
        HeroDetailBottomSheet.newInstance(hero, new HeroDetailBottomSheet.WatchlistToggleCallback() {
            @Override
            public void onSheetToggleWatchlist(HeroMetaEntity target) {
                target.isWatchlisted = !target.isWatchlisted;
                heroRepository.setWatchlisted(target.heroId, target.isWatchlisted);
                feedAdapter.notifyDataSetChanged();
            }
        }).show(getSupportFragmentManager(), "hero_detail_sheet");
    }

    private void syncSteamBannerState() {
        bannerController.bindSteamState(
                sessionManager.isSignedIn(),
                sessionManager.getPersonaName(),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (sessionManager.isSignedIn()) {
                            bottomNavBar.setSelectedItemId(R.id.nav_steam_audit);
                        } else {
                            launchSteamOpenId();
                        }
                    }
                });
    }

    private void launchSteamOpenId() {
        Intent intent = new Intent(this, SteamOpenIdAuthActivity.class);
        steamAuthLauncher.launch(intent);
    }
}
