package com.dotapulse.md3.auth;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private static final String PREFS_NAME = "dotapulse_steam_session";
    private static final String KEY_STEAM_ID_64 = "steam_id_64";
    private static final String KEY_ACCOUNT_ID_32 = "account_id_32";
    private static final String KEY_PERSONA_NAME = "persona_name";
    private static final String KEY_AVATAR_URL = "avatar_url";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void saveSession(long accountId32, String steamId64, String personaName, String avatarUrl) {
        prefs.edit()
                .putLong(KEY_ACCOUNT_ID_32, accountId32)
                .putString(KEY_STEAM_ID_64, steamId64 != null ? steamId64 : String.valueOf(SteamIdConverter.toSteamId64(accountId32)))
                .putString(KEY_PERSONA_NAME, personaName != null ? personaName : ("Player #" + accountId32))
                .putString(KEY_AVATAR_URL, avatarUrl != null ? avatarUrl : "")
                .apply();
    }

    public void updateProfileMetadata(String personaName, String avatarUrl) {
        prefs.edit()
                .putString(KEY_PERSONA_NAME, personaName)
                .putString(KEY_AVATAR_URL, avatarUrl)
                .apply();
    }

    public boolean isSignedIn() {
        return getAccountId32() > 0L;
    }

    public long getAccountId32() {
        return prefs.getLong(KEY_ACCOUNT_ID_32, -1L);
    }

    public String getSteamId64() {
        return prefs.getString(KEY_STEAM_ID_64, "");
    }

    public String getPersonaName() {
        return prefs.getString(KEY_PERSONA_NAME, "");
    }

    public String getAvatarUrl() {
        return prefs.getString(KEY_AVATAR_URL, "");
    }

    public void clearSession() {
        prefs.edit().clear().apply();
    }
}
