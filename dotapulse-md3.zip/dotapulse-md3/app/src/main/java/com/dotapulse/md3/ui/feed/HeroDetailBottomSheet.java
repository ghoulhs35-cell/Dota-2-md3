package com.dotapulse.md3.ui.feed;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.dotapulse.md3.R;
import com.dotapulse.md3.model.HeroMetaEntity;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.util.Locale;

public class HeroDetailBottomSheet extends BottomSheetDialogFragment {

    public interface WatchlistToggleCallback {
        void onSheetToggleWatchlist(HeroMetaEntity hero);
    }

    private HeroMetaEntity hero;
    private WatchlistToggleCallback callback;

    public static HeroDetailBottomSheet newInstance(HeroMetaEntity hero, WatchlistToggleCallback callback) {
        HeroDetailBottomSheet sheet = new HeroDetailBottomSheet();
        sheet.hero = hero;
        sheet.callback = callback;
        return sheet;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_hero_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (hero == null) {
            dismiss();
            return;
        }

        ShapeableImageView ivPortrait = view.findViewById(R.id.ivSheetHeroPortrait);
        TextView tvName = view.findViewById(R.id.tvSheetHeroName);
        TextView tvRoles = view.findViewById(R.id.tvSheetHeroRoles);
        TextView tvVerdict = view.findViewById(R.id.tvSheetVerdict);

        TextView tvImmortal = view.findViewById(R.id.tvBracketImmortal);
        LinearProgressIndicator progImmortal = view.findViewById(R.id.progressImmortal);
        TextView tvDivine = view.findViewById(R.id.tvBracketDivine);
        LinearProgressIndicator progDivine = view.findViewById(R.id.progressDivine);
        TextView tvArchon = view.findViewById(R.id.tvBracketArchon);
        LinearProgressIndicator progArchon = view.findViewById(R.id.progressArchon);
        TextView tvHerald = view.findViewById(R.id.tvBracketHerald);
        LinearProgressIndicator progHerald = view.findViewById(R.id.progressHerald);

        final MaterialButton btnWatchlist = view.findViewById(R.id.btnSheetToggleWatchlist);
        MaterialButton btnShare = view.findViewById(R.id.btnSheetShareHero);

        Glide.with(this)
                .load(hero.getHeroPortraitUrl())
                .placeholder(R.drawable.bg_hero_fallback_gradient)
                .into(ivPortrait);

        tvName.setText(String.format(Locale.US, "%s (%s-Tier • Score %.0f)",
                hero.localizedName, hero.tierLabel, hero.metaScore));
        tvRoles.setText(hero.primaryAttr + " • " + hero.attackType + " • " + hero.rolesCsv);
        tvVerdict.setText(hero.verdictSummary);

        tvImmortal.setText(String.format(Locale.US, "Immortal (Bracket 8): %.1f%% WR", hero.immortalWr));
        progImmortal.setProgress((int) Math.round(hero.immortalWr));

        tvDivine.setText(String.format(Locale.US, "Ancient / Divine (6–7): %.1f%% WR", hero.ancientDivineWr));
        progDivine.setProgress((int) Math.round(hero.ancientDivineWr));

        tvArchon.setText(String.format(Locale.US, "Archon / Legend (4–5): %.1f%% WR", hero.archonLegendWr));
        progArchon.setProgress((int) Math.round(hero.archonLegendWr));

        tvHerald.setText(String.format(Locale.US, "Herald – Crusader (1–3): %.1f%% WR", hero.heraldCrusaderWr));
        progHerald.setProgress((int) Math.round(hero.heraldCrusaderWr));

        btnWatchlist.setText(hero.isWatchlisted ? "Remove from Watchlist" : "Add to Watchlist");
        btnWatchlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) {
                    callback.onSheetToggleWatchlist(hero);
                }
                btnWatchlist.setText(hero.isWatchlisted ? "Remove from Watchlist" : "Add to Watchlist");
            }
        });

        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent(Intent.ACTION_SEND);
                sendIntent.setType("text/plain");
                sendIntent.putExtra(Intent.EXTRA_TEXT, hero.statusBannerTitle + "
" + hero.verdictSummary);
                startActivity(Intent.createChooser(sendIntent, "Share Hero Telemetry"));
            }
        });
    }
}
