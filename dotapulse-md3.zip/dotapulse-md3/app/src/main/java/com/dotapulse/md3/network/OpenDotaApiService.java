package com.dotapulse.md3.network;

import com.dotapulse.md3.model.HeroStatsDto;
import com.dotapulse.md3.model.PlayerHeroPerformance;
import com.dotapulse.md3.model.PlayerRecentMatch;
import com.dotapulse.md3.model.PlayerWinLossDto;
import com.dotapulse.md3.model.SteamPlayerProfile;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface OpenDotaApiService {
    @GET("heroStats")
    Call<List<HeroStatsDto>> getHeroStats();

    @GET("players/{accountId}")
    Call<SteamPlayerProfile> getPlayerProfile(@Path("accountId") long accountId);

    @GET("players/{accountId}/wl")
    Call<PlayerWinLossDto> getPlayerWinLoss(@Path("accountId") long accountId);

    @GET("players/{accountId}/heroes")
    Call<List<PlayerHeroPerformance>> getPlayerHeroes(@Path("accountId") long accountId);

    @GET("players/{accountId}/recentMatches")
    Call<List<PlayerRecentMatch>> getPlayerRecentMatches(@Path("accountId") long accountId);
}
