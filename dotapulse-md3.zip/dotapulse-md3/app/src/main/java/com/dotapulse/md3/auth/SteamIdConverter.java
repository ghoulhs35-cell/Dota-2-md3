package com.dotapulse.md3.auth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SteamIdConverter {

    public static final long STEAM_ID_64_BASE = 76561197960265728L;
    private static final Pattern PROFILE_URL_PATTERN =
            Pattern.compile("steamcommunity\.com/(?:profiles|openid/id)/(\d{17})");

    private SteamIdConverter() {}

    public static long toAccountId32(long steamId64) {
        if (steamId64 > STEAM_ID_64_BASE) {
            return steamId64 - STEAM_ID_64_BASE;
        }
        return steamId64;
    }

    public static long toSteamId64(long accountId32) {
        if (accountId32 > 0 && accountId32 < STEAM_ID_64_BASE) {
            return accountId32 + STEAM_ID_64_BASE;
        }
        return accountId32;
    }

    /**
     * Parses a raw 32-bit Dota 2 Friend ID, a 17-digit 64-bit SteamID,
     * or a steamcommunity.com/profiles/<id> URL into a 32-bit Dota 2 Account ID.
     * Returns -1 if input is invalid.
     */
    public static long parseToAccountId32(String rawInput) {
        if (rawInput == null) {
            return -1L;
        }
        String trimmed = rawInput.trim();
        if (trimmed.isEmpty()) {
            return -1L;
        }

        Matcher matcher = PROFILE_URL_PATTERN.matcher(trimmed);
        if (matcher.find()) {
            String digits = matcher.group(1);
            if (digits != null) {
                try {
                    long id64 = Long.parseLong(digits);
                    return toAccountId32(id64);
                } catch (NumberFormatException ignored) {
                    return -1L;
                }
            }
        }

        if (trimmed.matches("\d+")) {
            try {
                long value = Long.parseLong(trimmed);
                if (value > STEAM_ID_64_BASE) {
                    return toAccountId32(value);
                } else if (value > 0 && value <= 4294967295L) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                return -1L;
            }
        }
        return -1L;
    }
}
